package com.example.restaurentmanagement;

public class User {
    public String name,phone,email;

    public User(){

    }
    public User(String name,String email,String phone){

        this.name=name;
        this.email=email;
        this.phone=phone;
    }
}
