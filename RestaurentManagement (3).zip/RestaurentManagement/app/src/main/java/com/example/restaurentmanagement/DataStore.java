package com.example.restaurentmanagement;

public class DataStore {
    public static String address="";

    public DataStore(){

    }

    public void setAddress(String address) {
        this.address = address;
    }

    public  String getAddress() {
        return this.address;
    }
}
